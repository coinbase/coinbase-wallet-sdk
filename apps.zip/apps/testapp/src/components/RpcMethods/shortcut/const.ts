export const EXAMPLE_MESSAGE = `Example Message`;

export const ADDR_TO_FILL = 'ADDR_TO_FILL';
