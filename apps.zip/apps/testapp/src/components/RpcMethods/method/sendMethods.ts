import { RpcRequestInput } from './RpcRequestInput';

const ethSendTransaction: RpcRequestInput = {
  method: 'eth_sendTransaction',
  params: [
    { key: 'from', required: true },
    { key: 'to', required: true },
    { key: 'value', required: true },
    { key: 'gasLimit', required: true },
    { key: 'gasPriceInWei', required: true },
    { key: 'maxFeePerGas', required: true },
    { key: 'maxPriorityFeePerGas', required: true },
  ],
  format: (data: Record<string, string>) => [
    {
      from: data.from,
      to: data.to,
      value: data.value,
      gasLimit: data.gasLimit,
      gasPriceInWei: data.gasPriceInWei,
      maxFeePerGas: data.maxFeePerGas,
      maxPriorityFeePerGas: data.maxPriorityFeePerGas,
    },
  ],
};

export const sendMethods = [ethSendTransaction];
